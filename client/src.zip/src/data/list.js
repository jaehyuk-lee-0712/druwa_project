export const info = [
  {
    title: "스타벅스 안산고잔센트럴타워점",
    price: "$9,000",
    info1: "5.3km",
    info2: "카페",
    info3: "4.8",
  },
  {
    title: "스타벅스 안산중앙점",
    price: "$2,000",
    info1: "3.1km",
    info2: "카페",
    info3: "4.2",
  },
];

export const boardList = [
  {
    type: "업데이트",
    title: "드라이브 신규매장",
    date: "2024. 07. 02",
  },
  {
    type: "이벤트",
    title: "이벤트중인 매장",
    date: "2024. 07. 02",
  },
  {
    type: "이벤트",
    title: "이벤트중인 매장",
    date: "2024. 07. 02",
  },
  {
    type: "업데이트",
    title: "드라이브 신규매장",
    date: "2024. 07. 02",
  },
  {
    type: "이벤트",
    title: "이벤트중인 매장",
    date: "2024. 07. 02",
  },
  {
    type: "업데이트",
    title: "드라이브 신규매장",
    date: "2024. 07. 02",
  },
  {
    type: "업데이트",
    title: "드라이브 신규매장",
    date: "2024. 07. 02",
  },
  {
    type: "업데이트",
    title: "드라이브 신규매장",
    date: "2024. 07. 02",
  },
  {
    type: "이벤트",
    title: "이벤트중인 매장",
    date: "2024. 07. 02",
  },
  {
    type: "업데이트",
    title: "드라이브 신규매장",
    date: "2024. 07. 02",
  },
];

export const checkLists = [
  {
    title: "전체",
  },
  {
    title: "Starbucks",
  },
  {
    title: "McDonald",
  },
  {
    title: "Burger King",
  },
  {
    title: "Lotteria",
  },
];

export const moglogInfo = [
  {
    title: "Starbucks",
    open: "운영중",
    info1: "5.3km",
    info2: "카페",
    info3: "4.8",
  },
  {
    title: "McDonald",
    open: "",
    info1: "5.3km",
    info2: "카페",
    info3: "4.8",
  },
  {
    title: "Lotteria",
    open: "운영중",
    info1: "5.3km",
    info2: "카페",
    info3: "4.8",
  },
];
